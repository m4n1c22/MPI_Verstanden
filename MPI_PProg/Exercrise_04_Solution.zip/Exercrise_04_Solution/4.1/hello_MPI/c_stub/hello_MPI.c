#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define MAX_ARRAY_SIZE (2<<10)

int main(int argc, char **argv)
{
  // have variables for the rank and number of processes
  int iMyRank, iNumProcs;

  // initialize MPI, find out MPI size and rank
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &iNumProcs);
  MPI_Comm_rank(MPI_COMM_WORLD, &iMyRank);

  //PART B:
  srandom(MPI_Wtime()*100000);
  int numberOfElementsToSend=random()%100;
  int *myArray=(int*)malloc(sizeof(int)*MAX_ARRAY_SIZE);
  if (myArray==NULL)
    {
      printf("Not enough memory\n");
      exit(1);
    }
  int numberOfElementsReceived;
	
  // TODO: error message if too few processes


  // have only the first process execute the following code
  if (iMyRank == 0) 
    {
      printf("Sending %i elements\n",numberOfElementsToSend);
      // send "numberOfElementsToSend" elements
      MPI_Send(&numberOfElementsToSend,1, MPI_INT, 1, 0, MPI_COMM_WORLD); /* ping */
      MPI_Send(myArray, numberOfElementsToSend, MPI_INT, 1, 0, MPI_COMM_WORLD); /* ping */
       // received elements
      MPI_Recv(&numberOfElementsReceived,1, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
      MPI_Recv(myArray, numberOfElementsReceived, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 

      // the number of elements received should be stored in numberOfElementsReceiveds
      printf("Received %i elements\n",numberOfElementsReceived);
    }
  // TODO: work although too many processes	
  else { // iMyRank == 1
    // receive elements
    MPI_Recv(&numberOfElementsReceived,	1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
    MPI_Recv(myArray, numberOfElementsReceived, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
    // the number of elements received should be stored in numberOfElementsReceived
    printf("Received %i elements\n",numberOfElementsReceived);
    printf("Sending back %i elements\n",numberOfElementsToSend);
     // send "numberOfElementsToSend" elements
    MPI_Send(&numberOfElementsToSend,1, MPI_INT, 0, 0, MPI_COMM_WORLD);
    MPI_Send(myArray,numberOfElementsToSend, MPI_INT, 0, 0, MPI_COMM_WORLD); /* ping */
  }
  // finish MPI
  MPI_Finalize();
	
  return 0;
}
