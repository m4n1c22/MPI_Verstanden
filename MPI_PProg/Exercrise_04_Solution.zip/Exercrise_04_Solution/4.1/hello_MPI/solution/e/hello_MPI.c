#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define MAX_ARRAY_SIZE (2<<26)

int main(int argc, char **argv)
{
  // have variables for the rank and number of processes
  int iMyRank, iNumProcs;
  MPI_Status status;

  // initialize MPI, find out MPI size and rank
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &iNumProcs);
  MPI_Comm_rank(MPI_COMM_WORLD, &iMyRank);


  int *myArray=(int*)malloc(sizeof(int)*MAX_ARRAY_SIZE);
  if (myArray==NULL)
    {
      printf("Not enough memory\n");
      exit(1);
    }
  int numberOfElementsToSend;
  int numberOfElementsReceived;
	
  // PART C:
  if (iNumProcs < 2) {
    printf("Error: Run the program on 2 MPI tasks!\n");
    MPI_Abort(MPI_COMM_WORLD, 1);
  }

  for (numberOfElementsToSend=1;numberOfElementsToSend<MAX_ARRAY_SIZE;numberOfElementsToSend*=2)
    {
      if (iMyRank == 0) 
	{
	  double startTime=MPI_Wtime();
	  printf("Rank %2.1i: Sending %i elements\n",iMyRank,numberOfElementsToSend);
	  MPI_Send(myArray, numberOfElementsToSend, MPI_INT, 1, 0, MPI_COMM_WORLD);
	  // get correct amount of data
	  MPI_Probe(MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
	  MPI_Get_count(&status,MPI_INT,&numberOfElementsReceived);

	  MPI_Recv(myArray, numberOfElementsReceived, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
	  double endTime=MPI_Wtime();
	  printf("Rank %2.1i: Received %i elements\n",iMyRank, numberOfElementsReceived);
	  printf("Ping Pong took %f seconds\n",endTime-startTime);
	}	
      else if(iMyRank==1) {
	// get correct amount of data
	MPI_Probe(MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
	MPI_Get_count(&status,MPI_INT,&numberOfElementsReceived);
	MPI_Recv(myArray, numberOfElementsReceived, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
	printf("Rank %2.1i: Received %i elements\n",iMyRank,numberOfElementsReceived);
	printf("Rank %2.1i: Sending back %i elements\n",iMyRank,numberOfElementsToSend);
	MPI_Send(myArray,numberOfElementsToSend, MPI_INT, 0, 0, MPI_COMM_WORLD);
      }
    }
  // finish MPI
  MPI_Finalize();
  printf("Former rank %i terminates properly\n",iMyRank);	
  return 0;
}
