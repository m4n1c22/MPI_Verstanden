#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
  int iMyRank, iNumProcs;
  int data;


  // TODO: initialize MPI, find out MPI size and rank
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &iNumProcs);
  MPI_Comm_rank(MPI_COMM_WORLD, &iMyRank);

  if (iNumProcs != 2) {
    printf("Error: Run the program on 2 MPI tasks!\n");
    MPI_Abort(MPI_COMM_WORLD, 1);
  }

  if (iMyRank == 0) 
    {
	  printf("Please provide an integer value for the ping-message conent:");
	  scanf("%d",&data);	
      printf("Sending Ping ( %d)\n",data);
      MPI_Send(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD); /* ping */
      MPI_Recv(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
	  printf("Received Pong (%d)\n",data);	
	}
  // do proper receive and send for any other process
  else { // iMyRank == 1
    MPI_Recv(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	printf("Received Ping (%d)\n",data);
    data = (-1)*data;
    printf("Sending Pong ( %d)\n",data);
    MPI_Send(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD); /* pong */
  }

  // TODO: finish MPI
  MPI_Finalize();
	
  return 0;
}
