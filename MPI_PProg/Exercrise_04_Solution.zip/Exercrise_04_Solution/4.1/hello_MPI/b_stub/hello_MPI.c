#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define MAX_ARRAY_SIZE (2<<10)

int main(int argc, char **argv)
{
  // have variables for the rank and number of processes
  int iMyRank, iNumProcs;

  // initialize MPI, find out MPI size and rank
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &iNumProcs);
  MPI_Comm_rank(MPI_COMM_WORLD, &iMyRank);

 
  // PART B:
  srandom(MPI_Wtime()*100000);
  int numberOfElementsToSend=random()%100;
  int *myArray=(int*)malloc(sizeof(int)*MAX_ARRAY_SIZE); /* initialize a big array*/
  if (myArray==NULL)
    {
      printf("Not enough memory\n");
      exit(1);
    }
  int numberOfElementsReceived;

  // have only the first process execute the following code
  if (iMyRank == 0) 
    {
      printf("Sending %i elements\n",numberOfElementsToSend);
      // TODO: send "numberOfElementsToSend" elements
      // TODO: received elements
			
      // TODO: the number of elements received should be stored in numberOfElementsReceiveds
      printf("Received % elements\n",numberOfElementsReceived);
    }
  // else	
  else { // iMyRank == 1
    // TODO: receive elements

		
    // TODO: the number of elements received should be stored in numberOfElementsReceiveds
    printf("Received %i elements\n",numberOfElementsReceived);
			
    printf("Sending back %i elements\n",numberOfElementsToSend);
    // TODO: send "numberOfElementsToSend" elements
  }
  // finish MPI
  MPI_Finalize();
  printf("Former rank %2.1i about to close\n",iMyRank);	
	
  return 0;
}
