#include <stdio.h>
#include <memory.h>
#include "zlib.h"

typedef struct CGOLF
{
	int mode;
	z_stream strm;
	FILE * file;
	char * filePath;
	int blockSize;
	unsigned char * buffer;
}CGOLF; /* Compressed Game Of Life File */

int CGOLF_Init(CGOLF * cgolf,int fileBlockSize);
int CGOLF_in_open(CGOLF * cgolf, char * fileName);
int CGOLF_out_open(CGOLF * cgolf,char * fileName);
int CGOLF_in_read(CGOLF * cgolf,int nElements,unsigned char * elements);
int CGOLF_in_close(CGOLF * cgolf);
int CGOLF_out_write(CGOLF * cgolf,int nElements,unsigned char * elements);
int CGOLF_out_close(CGOLF * cgolf);
