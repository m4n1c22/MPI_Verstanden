#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include <omp.h>
#include <mpi.h>
#ifdef DEBUG
#define ON_DEBUG(x) x
#else
#define ON_DEBUG(x)
#endif

__inline int imin(int a,int b)
{
	return a<b?a:b;
}
typedef struct {
unsigned char status[2];} cell;



int main(int argc, char ** argv)
{
	int N,M,Iterations,NumberOfOutputIterations;
	int OutputCounter;
	char *InputFileName;
	int* OutputIterations=NULL;
	double StartTime,EndTime;
	/* Start MPI */
	MPI_Init(&argc,&argv);
	int ompMaxThreadCount=omp_get_max_threads();
	{ /* YOU DO NOT NEED TO MODIFY: Begin */
		int i;
		/* Process Input from command-line arguments */
		if (argc< 5)
			fprintf(stderr,"gol N M InputFile TotalIt NumOut It1 It2 ... It(NumOut)\n\tN,M: 100 ... 2^20\n\tInputfile: ASCII-encoded game filed, NxM elements, '0'=dead, '1'=alive\n\t TotalIt: Number of total iterations\n\t NumOut: Number of output-times\n\t It1 ... It(NumOut): NumOut-iteration times for output\n");

//		printf("argv[0]=%s,argv[1]=%s\n",argv[0],argv[1]);
		N=atoi(*++argv);
		M=atoi(*++argv);
		InputFileName=*++argv;
		Iterations=atoi(*++argv);
		NumberOfOutputIterations=atoi(*++argv);
//		printf("NumberOfOutputIterations=%i\n",NumberOfOutputIterations);

		if (NumberOfOutputIterations<0 || (OutputIterations=(int*)malloc(sizeof(int)*NumberOfOutputIterations))==NULL)
		{
//			fprintf(stderr,"Error: could not allocate output-time array. NumOut < 0 or out of memory.\n");		
			return -1;
		}
		else
		{
			OutputCounter=0;
			while(OutputCounter<NumberOfOutputIterations)
			{	

				OutputIterations[OutputCounter++]=atoi(*++argv);
			}
		}
		OutputIterations[OutputCounter++]=Iterations;

//		printf("\tDomain: %i x %i (N x M)\n\tInputfile: %s\n\tIterations=%i\n",N,M,InputFileName,Iterations);
//		for (i=0;i<NumberOfOutputIterations;i++)
//			printf("\tOutput after %i iterations\n",OutputIterations[i]);
//		printf("\tOutput after %i iterations\n",Iterations);
	} /* YOU DO NOT NEED TO MODIFY: End */


	/* prepare game */
	int rank, numProc;
	MPI_Comm_size(MPI_COMM_WORLD,&numProc);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);

	int domainRowOffset,
	    domainColumnOffset,
	    localDomainRowCount,
	    localDomainColumnCount;
	int haloSize=2;
	
	int rowBlocks,
	    columnBlocks;

	/* Compute partitioning */
	rowBlocks=numProc;
	columnBlocks=1;
	while (rowBlocks>columnBlocks && rowBlocks%2==0)
	{
		columnBlocks*=2;
		rowBlocks/=2;
	}
	printf("Domain (%i x %i) partitioned in %i columns and %i rows\n",N,M,columnBlocks,rowBlocks);
	
	int rowBlockNumber,columnBlockNumber;
	rowBlockNumber=(rank%rowBlocks);
	columnBlockNumber=(rank/rowBlocks);
	printf("%i\trow=%i,column=%i\n",rank,rowBlockNumber,columnBlockNumber);
	

	domainRowOffset=(N/rowBlocks)*(rank%rowBlocks);
	domainColumnOffset=(M/columnBlocks)*(rank/rowBlocks);
	ON_DEBUG(printf("%i\tLocal offset: (%i,%i)\n",rank,domainRowOffset,domainColumnOffset);)

	localDomainRowCount=imin(M,(M*(rowBlockNumber+1)/rowBlocks))-(M*rowBlockNumber/rowBlocks)+2*haloSize;
	localDomainColumnCount=imin(N,(N*(columnBlockNumber+1)/columnBlocks))-(N*columnBlockNumber/columnBlocks)+2*haloSize;
	
	ON_DEBUG(printf("%i\tlocal domain size: %i x %i (incl ghostcells for a halo of %i)\n",rank,localDomainRowCount,localDomainColumnCount,haloSize);)

	/* Compute neighbouring ranks */	
	int nextColBlockRank,prevColBlockRank,nextRowBlockRank,prevRowBlockRank;
	int prevRowPrevColBlockRank, prevRowNextColBlockRank,nextRowPrevColBlockRank,nextRowNextColBlockRank;

	if (rowBlockNumber-1<0)
	{
		prevRowPrevColBlockRank=MPI_PROC_NULL;
		prevRowBlockRank=MPI_PROC_NULL;
		prevRowNextColBlockRank=MPI_PROC_NULL;
	}
	else 
	{
		if (columnBlockNumber-1<0)
			prevRowPrevColBlockRank=MPI_PROC_NULL;
		else
			prevRowPrevColBlockRank=rank-1-rowBlocks;
		prevRowBlockRank=rank-1;
		if (columnBlockNumber+1>=columnBlocks)
			prevRowNextColBlockRank=MPI_PROC_NULL;
		else
			prevRowPrevColBlockRank=rank-1+rowBlocks;;
	}


	if (rowBlockNumber+1>=rowBlocks) 
	{
		nextRowPrevColBlockRank=MPI_PROC_NULL;
		nextRowBlockRank=MPI_PROC_NULL;
		nextRowNextColBlockRank=MPI_PROC_NULL;
	}
	else 
	{
		if (columnBlockNumber-1<0) 
			nextRowPrevColBlockRank=MPI_PROC_NULL;
		else
			nextRowPrevColBlockRank=rank+1-rowBlocks;
		nextRowBlockRank=rank+1;
		if (columnBlockNumber+1>=columnBlocks)
			nextRowNextColBlockRank=MPI_PROC_NULL;
		else
			nextRowNextColBlockRank=rank+1+rowBlocks;
	}
	if (columnBlockNumber-1<0) prevColBlockRank=MPI_PROC_NULL;
	else prevColBlockRank=rank-rowBlocks;
	if (columnBlockNumber+1>=columnBlocks) nextColBlockRank=MPI_PROC_NULL;
	else nextColBlockRank=rank+rank-rowBlocks;
	
	
	ON_DEBUG(printf ("%i\t%2i %2i %2i\n\t%2i %2i %2i\n\t%2i %2i %2i\n",rank,prevRowPrevColBlockRank,prevRowBlockRank,prevRowNextColBlockRank,prevColBlockRank,0,nextColBlockRank,nextRowPrevColBlockRank,nextRowBlockRank,nextRowNextColBlockRank);)
	
		

	/* allocate domain */
	cell * cellBuffer;
	cell ** localDomain;

	cellBuffer=(cell*)malloc(sizeof(cell)*localDomainColumnCount*localDomainRowCount);
	if (cellBuffer==NULL) MPI_Abort();
	localDomain=(cell*)malloc(sizeof(cell*)*localDomainRowCount);
	if (localDomain==NULL) MPI_Abort();
	for (row=0;row<localDomainRowCount;row++)	
	  localDomain[row]=cellBuffer+localDomainColumnCount*row;

			


	/* read the input */
	
	for (row=haloSize;row<(localDomainRowCount-haloSize);row++)
		for (column=haloSize;column<(localDomainColumnCount-haloSize);column++)
		localDomain[row][column]=inputFile(N,M,domainRowOffset+row,domainColumnOffset+column);

	/* create MPI Data-types for commuication */
	MPI_Datatype	haloPrevRowPrevCol,
			haloPrevCol,
			haloPrevRowNextCol,
			haloPrevRow,
			haloNextRow,
			haloNextRowPrevCol,
			haloNextRowNextCol;
/*
	int MPI_Type_indexed(
               int count,
               int blocklens[],
               int indices[],
               MPI_Datatype old_type,
               MPI_Datatype *newtype )
*/
/*	MPI_Type_indexed(haloSize, */
	
	
	int nextOutput=0;
	/* start time measurement */
	StartTime = omp_get_wtime ( );
	/* implement your program here */		
	int timeStep=0;
	
	int maxRequestCount = (2*haloSize+rowCount)*2;
	MPI_Request * recvRequestArray;
	MPI_Request * sendRequestArray;
	recvRequestArray=(MPI_Request*)malloc(sizeof(MPI_Request)*maxRequestCount)
	sendRequestArray=(MPI_Request*)malloc(sizeof(MPI_Request)*maxRequestCount)
		
	MPI_Type CELLTYPE,LOCALCOLUMNTYPE,HALO_CORNERTYPE,HALO_ROWTYPE,HALO_COLUMNTYPE;
#ifdef C_LIKE_STRUCT		
	int CellType_BlockLengths[4]={1,1,1,1}
	int CellTypeOffsets[4]={0,0,1,1};

	MPI_Type CellTypeTypes[4]={MPI_LB,MPI_CHAR,MPI_CHAR,MPI_UB};


	MPI_Type_struct(4,CellType_BlockLengths,CellTypeOffsets,CellTypeTypes,&CELLTYPE);
#else
	MPI_Type_vector(2,2,1,MPI_CHAR,&CELLTYPE);
#endif
	MPI_Type_vector(haloSize*(colcalDomainColumnCount-(2*haloSize)),haloSize,colcalDomainColumnCount,CELLTYPE,&HALO_COLUMNTYPE);

	MPI_Type_vector(haloSize*haloSize,haloSize,localDomainColumnCount,CELLTYPE,&HALO_CORNERTYPE);
	MPI_Type_vecotr((localDomainColumnCount-2*haloSize)*haloSize,(localDomainColumnCount-2*haloSize),localDomainColumnCount,CELLTYPE,&HALO_ROWTYPE);


	for (timeStep=0;timeStep<Iterations;timeStep+=haloSize)
	{
		/* exchange halo */
		/* simple exchange, no direct opmitization */
		recvRequestCount=0;
		/* prevRowPrevCol Halo-Exchange */
		for  (row=0;row<haloSize;row++)
		{
		   MPI_Irecv(localDomain[row],haloSize,CELLTYPE,prevRowPrevColBlockRank,8,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		   MPI_Isend(localDomain[row+haloSize]+haloSize,CELLTYPE,prevRowPrevColBlockRank,1,MPI_COMM_WORLD,sendRequestArray+requestCounter);	
		   requestCounter++;	
		}
		/* prevRwo Halo-Exchange */
		for (row=localDomainRowCount-(haloSize);row<localDomainRowCount;row++)
		{  
 		  MPI_Irecv(localDomain[row]+haloSize,localDomainRowCount-(2*haloSize),CELLTYPE,prevRowBlockRank,7,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		  MPI_Isend(localDomain[row+haloSize]+haloSize,localDomainRowCount-(2*haloSize),CELLTYPE,prevRowBlockRank,2,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		  requestCounter++;
		}
		/* prevRowNextCol */ 
		for (row=localDomainRowCount-(haloSize);row<localDomainRowCount;row++)
		{  
 		  MPI_Irecv(localDomain[row]+localDomainRowCount-haloSize,haloSize,CELLTYPE,prevRowNextColBlockRank,6,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		  MPI_Isend(localDomain[row+haloSize]+localDomainRowCount-haloSize,haloSize,CELLTYPE,prevRowBlockRank,2,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		  requestCounter++;
		}

		/* left and right are a bit more difficult, as they are not consecutive */
		/* bottom is easy again */
		/* nextRowPrevCol Halo-Exchange */
		for  (row=localDomainRowCount-(haloSize);row<localDomainRowCount;row++)
		{
		   MPI_Irecv(localDomain[row],haloSize,CELLTYPE,nextRowPrevColBlockRank,1,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		   MPI_Isend(localDomain[row-haloSize]+haloSize,CELLTYPE,prevRowPrevColBlockRank,6,MPI_COMM_WORLD,sendRequestArray+requestCounter);	
		   requestCounter++;	
		}
		/* prevRwo Halo-Exchange */
		for (row=localDomainRowCount-(haloSize);row<localDomainRowCount;row++)
		{  
 		  MPI_Irecv(localDomain[row]+haloSize,localDomainRowCount-(2*haloSize),CELLTYPE,prevRowBlockRank,2,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		  MPI_Isend(localDomain[row-haloSize]+haloSize,localDomainRowCount-(2*haloSize),CELLTYPE,prevRowBlockRank,7,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		  requestCounter++;
		}
		/* prevRowNextCol */ 
		for (row=localDomainRowCount-(haloSize);row<localDomainRowCount;row++)
		{  
 		  MPI_Irecv(localDomain[row]+localDomainRowCount-haloSize,haloSize,CELLTYPE,prevRowNextColBlockRank,3,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		  MPI_Isend(localDomain[row-haloSize]-haloSize+localDomainRowCount,haloSize,CELLTYPE,prevRowBlockRank,8,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		  requestCounter++;
		}

		/* compute game */

		for (subStep=0;subStep<haloSize;subStep++)
		{
			for (row=haloSize-subStep;row<(localDomainRowCount-(haloSize-subStep));row++)
			{	
				for (column=haloSize-subStep;column<(localDomainColumnCount-(haloSize-subStep));column++)
				{
					int livingNeightbours=0;
					livingNeightbours+=localDomain[row-1][columns-1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row-1][columns-0].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row-1][columns+1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row-0][columns-1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row-0][columns+1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row+1][columns-1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row+1][columns-0].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row+1][columns+1].status[(timeStep+subStep)%2];
					if (livingNeightbours==3) localDomain[row][column].status[(timeStep+subStep+1)%2]=1;
					else if (livingNeightbours!=2) localDomain[row][column].status[(timeStep+subStep+1)%2]=0;		
				}	
			}
			if (nextOutput < NumberOfOutputIterations && OutputIterations[nextOutput]==(timeStep+subStep))
			{
				/* output here */
				nextOutput++;	
				write	
			}
		}
	}
	/* stop time measurement */
	EndTime = omp_get_wtime();
	
	/* write the data after the last iteration to disk */
	MPI_Finalize();
	return 0;

}

