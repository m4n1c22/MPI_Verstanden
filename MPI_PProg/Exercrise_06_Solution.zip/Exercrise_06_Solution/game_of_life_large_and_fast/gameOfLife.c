#include <mpi.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "zlib.h"
#include "CGOLF.h"
#include <unistd.h>

/* Terminology:
    local = the variable denotes information about the local block repsenting a partition of the game of life field
    global = the variable dnotes information about the global game of life field
    total = acutal cells + halo, can be omitted
    payload = the actual game of life cells without the halo
*/



typedef enum {
	BOUNDRY_LOWERBOUND=0,
	BOUNDRY_ALIVE=1,
	BOUNDRY_DEAD=2,
	BOUNDRY_PERIODIC=3,
	BOUNDRY_UPPERBOUND} boundryType;

#ifndef BOUNDRY_TYPE
	const boundryType BOUNDRY=BOUNDRY_DEAD;
//	const boundryType BOUNDRY=BOUNDRY_ALIVE;
#else
	const boundryType BOUNDRY=BOUNDRY_TYPE;
#endif

typedef struct
{
    int globalColumnOffset,
        globalRowOffset,
        localRowCount, 
        localColumnCount,
        lM,lN;
    MPI_Comm com;
    int rank;
}blockDescriptor;

int mapRank(int x,int y,int maxX,int maxY,int wrapX,int wrapY)
{
    // Check if the x is out of the allowed area
    if (x<0 || x>=maxX)
    {
        if (wrapX)
        {
            x=(x+maxX)%maxX;
        }
        else
            return MPI_PROC_NULL;
    }
    if (y<0 ||y>=maxY)
    {
        if (wrapY)
        {
            y=(y+maxY)%maxY;
        }
        else
            return MPI_PROC_NULL;
    }    
    return x+maxX*y;
}
int writeGOLData(CGOLF * cgolf,char* fileName,int globalWidth,int globalHeight,int localBasePayloadWidth,int localBasePayloadHeight,int halo,unsigned char * localField,int xOversizeCount,int yOversizeCount,int blockXCount,int blockYCount,MPI_Comm comm)
{
    int iRank;
    MPI_Comm_rank(comm,&iRank);
    int iSize;
    MPI_Comm_size(comm,&iSize);
    

    
    /* the ranks other than 0 only have to receive thier data linewise; however the master has to relate the request to the corresponding lines and do all the work for the IO as the compressed file works as a stream */
    if (iRank==0)
    {
        int bytesToRead=0;
        int procOffsetBase=0;
        unsigned char * sendBuffer;
        sendBuffer=(unsigned char*)malloc(sizeof(unsigned char)*(localBasePayloadWidth+1));
        /* open the compressed stream */
        CGOLF_out_open(cgolf,fileName);

        /* for all rows*/
        for (int blockY=0;blockY<blockYCount;blockY++)
        {
            int localPayloadHeight;
            if (blockY<yOversizeCount) /* is the local payload height oversized? */
                localPayloadHeight=localBasePayloadHeight+1;
            else
                localPayloadHeight=localBasePayloadHeight;
            /* process the local coordinates*/
            for (int localY=0;localY<localPayloadHeight;localY++)
            {    
                /* process the the whole row*/
                for (int blockX=0;blockX<blockXCount;blockX++)
                {
                    int iRequestRank=blockX+blockY*blockXCount;
                    int localTotalWidth;
                    int localPayloadWidth;

                    /* check if target rank is oversize */
                    if (blockX<xOversizeCount) /* yes it is */
                        localPayloadWidth=localBasePayloadWidth+1;
                    else
                        localPayloadWidth=localBasePayloadWidth;
                    localTotalWidth=localPayloadWidth+2*halo;

                    if (iRequestRank==0)
                    {
                        /* local copy, no MPI communication necessary*/
                        CGOLF_out_write(cgolf,localPayloadWidth,&(localField[(localTotalWidth)*(halo+localY)+halo]));

                    }
                    else
                    {
                        /* read the number of elements our target needs from the compressed stream */
                        MPI_Recv(sendBuffer,localPayloadWidth,MPI_BYTE,iRequestRank,0,comm,MPI_STATUS_IGNORE);
                        CGOLF_out_write(cgolf,localPayloadWidth,sendBuffer);
                    }
                }
            }
        }
        CGOLF_out_close(cgolf);
    }
    else
    {
        int blockX,blockY;
        blockY=iRank/blockXCount;
        blockX=iRank%blockXCount;
        
        int localPayloadHeight;
        int localTotalWidth;
        int localPayloadWidth;
        if (blockY<yOversizeCount) /* is the local payload height oversized? */
            localPayloadHeight=localBasePayloadHeight+1;
        else
            localPayloadHeight=localBasePayloadHeight;
        
        /* check if target rank is oversize */
        if (blockX<xOversizeCount) /* yes it is */
            localPayloadWidth=localBasePayloadWidth+1;
        else
            localPayloadWidth=localBasePayloadWidth;
        localTotalWidth=localPayloadWidth+2*halo;

        for (int localY=0;localY<localPayloadHeight;localY++)
        {
            MPI_Send(&(localField[localTotalWidth*(halo+localY)+halo]),localPayloadWidth,MPI_BYTE,0,0,comm);
        }        
    }    
}


int readGOLData(CGOLF * cgolf,char* fileName,int globalWidth,int globalHeight,int localBasePayloadWidth,int localBasePayloadHeight,int halo,unsigned char * localField,int xOversizeCount,int yOversizeCount,int blockXCount,int blockYCount,MPI_Comm comm)
{
    int iRank;
    MPI_Comm_rank(comm,&iRank);
    int iSize;
    MPI_Comm_size(comm,&iSize);
    

    
    /* the ranks other than 0 only have to receive thier data linewise; however the master has to relate the request to the corresponding lines and do all the work for the IO as the compressed file works as a stream */
    if (iRank==0)
    {
        int bytesToRead=0;
        int procOffsetBase=0;
        unsigned char * sendBuffer;
        sendBuffer=(unsigned char*)malloc(sizeof(unsigned char)*(localBasePayloadWidth+1));
        /* open the compressed stream */
        CGOLF_in_open(cgolf,fileName);

        /* for all rows*/
        for (int blockY=0;blockY<blockYCount;blockY++)
        {
            int localPayloadHeight;
            if (blockY<yOversizeCount) /* is the local payload height oversized? */
                localPayloadHeight=localBasePayloadHeight+1;
            else
                localPayloadHeight=localBasePayloadHeight;
            /* process the local coordinates*/
            for (int localY=0;localY<localPayloadHeight;localY++)
            {    
                /* process the the whole row*/
                for (int blockX=0;blockX<blockXCount;blockX++)
                {
                    int iRequestRank=blockX+blockY*blockXCount;
                    int localTotalWidth;
                    int localPayloadWidth;

                    /* check if target rank is oversize */
                    if (blockX<xOversizeCount) /* yes it is */
                        localPayloadWidth=localBasePayloadWidth+1;
                    else
                        localPayloadWidth=localBasePayloadWidth;
                    localTotalWidth=localPayloadWidth+2*halo;

                    if (iRequestRank==0)
                    {
                        /* local copy, no MPI communication necessary*/
                        CGOLF_in_read(cgolf,localPayloadWidth,&(localField[(localTotalWidth)*(halo+localY)+halo]));

                    }
                    else
                    {
                        /* read the number of elements our target needs from the compressed stream */
                        CGOLF_in_read(cgolf,localPayloadWidth,sendBuffer);
                        MPI_Send(sendBuffer,localPayloadWidth,MPI_BYTE,iRequestRank,0,comm);                                           
                    }
                }
            }
        }
        CGOLF_in_close(cgolf);
    }
    else
    {
        int blockX,blockY;
        blockY=iRank/blockXCount;
        blockX=iRank%blockXCount;
        
        int localPayloadHeight;
        int localTotalWidth;
        int localPayloadWidth;
        if (blockY<yOversizeCount) /* is the local payload height oversized? */
            localPayloadHeight=localBasePayloadHeight+1;
        else
            localPayloadHeight=localBasePayloadHeight;
        
        /* check if target rank is oversize */
        if (blockX<xOversizeCount) /* yes it is */
            localPayloadWidth=localBasePayloadWidth+1;
        else
            localPayloadWidth=localBasePayloadWidth;
        localTotalWidth=localPayloadWidth+2*halo;

        for (int localY=0;localY<localPayloadHeight;localY++)
        {
            MPI_Recv(&(localField[localTotalWidth*(halo+localY)+halo]),localPayloadWidth,MPI_BYTE,0,0,comm,MPI_STATUS_IGNORE);
        }        
    }    
}




int main(int argc,char** argv)
{
	/* YOU DO NOT NEED TO MODIFY: End */
	int globalWidth,globalHeight,Iterations,NumberOfOutputIterations;
	int OutputCounter;
	char *InputFileName;
	int* OutputIterations=NULL;
	char * OutputFileNameBase=InputFileName;
	double SetupStart,SetupEnd,ComputeStart,ComputeEnd;
	/* YOU DO NOT NEED TO MODIFY: Begin */

	/* Init the MPI Library */
	MPI_Init(&argc,&argv);
	int iRank,iSize;
	MPI_Comm_rank(MPI_COMM_WORLD,&iRank);
	MPI_Comm_size(MPI_COMM_WORLD,&iSize);

	

	if (iRank==0)
	{
		/* this is the master */
	
		/* YOU DO NOT NEED TO MODIFY: Begin */
		/* Manage Command Line Interface */
		int i;
		/* Process Input from command-line arguments */
		if (argc< 5)
			fprintf(stderr,"%s N M InputFile TotalIt NumOut It1 It2 ... It(NumOut)\n\tN,M: 1 ... 2^20\n\tInputfile: ZLIB compressed game filed; NxM elements, 0=dead, !0=alive\n\t TotalIt: Number of total iterations\n\t NumOut: Number of output-times\n\t It1 ... It(NumOut): NumOut-iteration times for output\n",argv[0]);

		globalWidth=atoi(*++argv);
		globalHeight=atoi(*++argv);
		InputFileName=*++argv;
		Iterations=atoi(*++argv);
		NumberOfOutputIterations=atoi(*++argv);
//		fprintf(stderr,"Reading %i output times\n",NumberOfOutputIterations);
		if (NumberOfOutputIterations<0 || (OutputIterations=(int*)malloc(sizeof(int)*(NumberOfOutputIterations+1)))==NULL)
		{
			return -1;
		}
		else
		{
			OutputCounter=0;
			while(OutputCounter<NumberOfOutputIterations)
			{

				OutputIterations[OutputCounter++]=atoi(*++argv);
			}
		}
		OutputIterations[OutputCounter++]=Iterations;

		int ofnbLen=strnlen(InputFileName,1000);
		OutputFileNameBase=(char*)malloc(sizeof(char)*(ofnbLen+1));
		strncpy(OutputFileNameBase,InputFileName,ofnbLen);

		if (ofnbLen>5 &&InputFileName[ofnbLen-1]=='f' && InputFileName[ofnbLen-2]=='l' && InputFileName[ofnbLen-3]=='o' && InputFileName[ofnbLen-4]=='g' && InputFileName[ofnbLen-5]=='c' && InputFileName[ofnbLen-6]=='.' )
		{
			// it ends with .golf 
			OutputFileNameBase[ofnbLen-6]=0;

		}
		/* YOU DO NOT NEED TO MODIFY: End */
	}
	
	/* Broadcast non I/O relevant information, namely N,M,Iterations,NumberOfOutputIterations,OutputIterations */
	MPI_Bcast(&globalWidth,1,MPI_INT,0,MPI_COMM_WORLD);
	MPI_Bcast(&globalHeight,1,MPI_INT,0,MPI_COMM_WORLD);
	MPI_Bcast(&Iterations,1,MPI_INT,0,MPI_COMM_WORLD);
	MPI_Bcast(&NumberOfOutputIterations,1,MPI_INT,0,MPI_COMM_WORLD);
	if (iRank!=0)
	{
		OutputIterations=(int*)malloc(sizeof(int)*(NumberOfOutputIterations+1));
	}
	MPI_Bcast(OutputIterations,NumberOfOutputIterations,MPI_INT,0,MPI_COMM_WORLD);


	/* ALL PROCESS COMPUTE DOMAIN DECOMPOSITION INFORMATION IN SYNC */
	/* How many of the MPI Processes can we really use! */
	/* Rule #1: No process may handle less than minCellsPerProc of cells, if so the communication overhead is too large, its better to leave processes idle */
	/* Rule #2: We use a simple hierarchical partitioning method, which only works for powers of two. Therefore we stop splitting, if we waste too many processes */

	int localPayloadBlockWidth=globalWidth,
		localPayloadBlockHeight=globalHeight;
	int widthBlockCount=1,
		heightBlockCount=1;

	double fPowerOfTwo=log(iSize)/log(2);
	double fIdle;
	int haloSize=0.01*(globalWidth<globalHeight?globalHeight:globalWidth);
    if (haloSize==0) haloSize=1;
	int recursiveSplits=0,
		cellsPerProc=(globalWidth+2*haloSize)*(globalHeight+2*haloSize);
	int availableProcs=iSize;
	int usedProcs=0;

    // the minimum number of cells per process should be min(
	int minCellsPerProc=globalWidth<globalHeight?globalWidth:globalHeight;
	int maxWasteProcs=0.1*availableProcs;

	int iWastedProcs=0;
#ifdef DEBUG
	if (iRank==0)
	{
		printf("Max Idle Processes: %i\n",maxWasteProcs);
		printf("MinCellsPerProcess: %i\n",minCellsPerProc);
	}
#endif 
//    int localBlockWidth,localBlockHeight;
	/* as long as we have more than one process*/
	while(availableProcs>1)
	{
		// simple check if we can divide by 2 without remainder)
		if (!(availableProcs&1))
		{
			/* check if after the split each process would have sufficient amount of work */
			if (cellsPerProc/2<minCellsPerProc)
				break;
			recursiveSplits++;
			availableProcs/=2;
			cellsPerProc/=2;
			/* compute the local sizes */
			localPayloadBlockWidth=globalWidth/widthBlockCount;
			localPayloadBlockHeight=globalHeight/heightBlockCount;
			if (localPayloadBlockWidth>localPayloadBlockHeight)
			{
				/* split the cell block along the width to minnimize communication */
				widthBlockCount*=2;
			}
			else
			{
				/* split the cell block along the height to minnimize communication */
				heightBlockCount*=2;
			}
		}
		else
		{	
			/* check if preparing another split would waste too many processes*/
			if ((iWastedProcs+(int)pow(2,recursiveSplits))>maxWasteProcs)
				break;
			availableProcs--;
			usedProcs++;
			iWastedProcs+=pow(2,recursiveSplits);
		}
	}

	/* if there are still processes available for the lowes recursion level, try to fit them to the block */
	while(availableProcs>1)
	{
		if (cellsPerProc/availableProcs<minCellsPerProc)
		{
			availableProcs--;
			iWastedProcs+=pow(2,recursiveSplits);
		}
		else
		{
			/* enough work, break now */
			cellsPerProc/=availableProcs;
			/* recompute the split */
			/* compute the local sizes */
			localPayloadBlockWidth=globalWidth/widthBlockCount;
			localPayloadBlockHeight=globalHeight/heightBlockCount;
			if (localPayloadBlockWidth>localPayloadBlockHeight)
			{
				/* split the cell block along the width to minnimize communication */
				widthBlockCount*=availableProcs;
			}
			else
			{
				/* split the cell block along the height to minnimize communication */
				heightBlockCount*=availableProcs;
			}


			break;
		}
	}
    /* ***************************************************************************************
     * *                                                                                     *
     * *             Modify the communicator and use the new smalle communicator from        *
     * *             now on.                                                                 *
     * *                                                                                     *
     * *                                                                                     *
     * *************************************************************************************** */

	MPI_Comm comm;
	MPI_Group          group, newgroup;
	/* get the current communicators group */
	MPI_Comm_group(MPI_COMM_WORLD, &group);
	{
		int * excludeList;
		int excludeListSize=iWastedProcs;
		excludeList=(int*)malloc(sizeof(int)*excludeListSize);
		for (int i=0;i<iWastedProcs;i++)
			excludeList[i]=iSize-(i+1);
		MPI_Group_excl(group, excludeListSize,excludeList, &newgroup);
	}
	MPI_Comm_create(MPI_COMM_WORLD, newgroup,&comm);
	iSize=iSize-iWastedProcs;

    

    /* recompute the local dimensions */
	int localBaseWidth=globalWidth/widthBlockCount;
	int localBaseHeight=globalHeight/heightBlockCount;

//////////////////    int localPayloadWidth,localPayloadHeight;
	int neighbourMatrix[3][3];
    
    int rowOversizeCount=0;
    int columnOversizeCount=0;




	/* compute for which block this process is responsible in the GoL-Domain */
	int localBlockXIndex=-1,
		localBlockYIndex=-1;
	
    if (iRank < iSize)
    {
        MPI_Comm_rank(comm,&iRank);

        localBlockXIndex=iRank%widthBlockCount;
        localBlockYIndex=iRank/widthBlockCount;

        int iXLeftover=globalWidth%widthBlockCount,
            iYLeftover=globalHeight%heightBlockCount;

        int	localPayloadWidth=globalWidth/widthBlockCount,
            localPayloadHeight=globalHeight/heightBlockCount;


        int globalXOffset=localBlockXIndex*localPayloadWidth,
            globalYOffset=localPayloadHeight*localBlockYIndex;
        if (iXLeftover>localBlockXIndex)
        {
            localPayloadWidth++;
            globalXOffset+=localBlockXIndex;
        }
        if (iYLeftover>localBlockYIndex)
        {
            localPayloadHeight++;
            globalYOffset+=localBlockYIndex;
        }

        rowOversizeCount=iXLeftover;
        columnOversizeCount=iYLeftover;


        /* after adapting the local width compute the final local block dimensions*/
        int localTotalWidth=localPayloadWidth+2*haloSize,
            localTotalHeight=localPayloadHeight+2*haloSize;


        /* setup neighbour matrix */
        for (int i=-1;i<2;i++)
            for (int j=-1;j<2;j++)
            {
                // compute the correct neighbouring communication partners
                neighbourMatrix[1+i][1+j]=mapRank(localBlockXIndex+j,localBlockYIndex+i,widthBlockCount,heightBlockCount,BOUNDRY==BOUNDRY_PERIODIC,BOUNDRY==BOUNDRY_PERIODIC);	
                //        neighbourMatrix[1+i][1+j]=(i+1)*3+j+1;
            }

#ifdef DEBUG
        printf("Process %i handling GoL-Block %i,%i; offset at %i,%i; dimensions %i,%i\tNeighbours:",iRank,localBlockXIndex,localBlockYIndex,globalXOffset,globalYOffset,localPayloadWidth,localPayloadHeight);
        for (int i=0;i<3;i++)for(int j=0;j<3;j++)
            printf(" %i",neighbourMatrix[i][j]);
        printf("\n");
#endif 


        /* create MPI data-types for boundry exchange: corner,column,row */
        MPI_Datatype MPI_GOL_CORNER,MPI_GOL_COLUMN,MPI_GOL_ROW;
        MPI_Type_vector(haloSize,haloSize,localTotalWidth,MPI_CHAR,&MPI_GOL_CORNER); MPI_Type_commit(&MPI_GOL_CORNER);
        MPI_Type_vector(haloSize,localPayloadHeight,localTotalWidth,MPI_CHAR,&MPI_GOL_COLUMN);MPI_Type_commit(&MPI_GOL_COLUMN);
        MPI_Type_vector(localPayloadWidth,haloSize,localTotalWidth,MPI_CHAR,&MPI_GOL_ROW);MPI_Type_commit(&MPI_GOL_ROW);












        /* Implement the game of life here */
        /* CI: parallelization update: all N and M are replaced with their localized lN and lM except for I/O. Permanent Dead/Alive Cells are positiond in the HALO */
        unsigned long gameFieldSize=localTotalWidth*localTotalHeight;
        unsigned char * gameFieldSrc;
        unsigned char * gameFieldDst;
        unsigned char * gameFieldTmp;
        gameFieldSrc=(unsigned char*)malloc(sizeof(unsigned char)*gameFieldSize);
        gameFieldDst=(unsigned char*)malloc(sizeof(unsigned char)*gameFieldSize);
        if (gameFieldSrc==NULL || gameFieldDst==NULL)
        {
            fprintf(stderr,"Malloc for game field failed: tried to allocated %lu bytes of memory\n",gameFieldSize);
        }



        /* Initialize the halo for non-wraparound boundaries */
        if (BOUNDRY!=BOUNDRY_PERIODIC)
        {   
            char boundryCellState;
            if (BOUNDRY==BOUNDRY_ALIVE) boundryCellState=1;
            else boundryCellState=0;
            /* top and bottom */
            for (int x=0;x<localTotalWidth;x++)
                for (int y=0;y<haloSize;y++)
                {
                    gameFieldSrc[y*localTotalWidth+x]=boundryCellState;
                    gameFieldSrc[(localPayloadHeight+haloSize)*localTotalWidth+(x)]=boundryCellState;
                }

            /* left and right */
            for (int y=haloSize;y<haloSize+localPayloadHeight;y++)
                for (int x=0;x<haloSize;x++)
                {
                    gameFieldSrc[y*localTotalWidth+x]=boundryCellState;
                    gameFieldSrc[y*localTotalWidth+(x+localPayloadWidth+haloSize)]=boundryCellState;
                }            
        }
        
        /* read local data using our distributed read routine*/
        CGOLF cgolf;
        CGOLF_Init(&cgolf,1024);
        readGOLData(&cgolf,InputFileName,globalWidth,globalHeight,localBaseWidth,localBaseHeight,haloSize,gameFieldSrc,
                        rowOversizeCount,columnOversizeCount,widthBlockCount,heightBlockCount,comm);


        /* the local grid has been successfully loaded*/




        /* Implement Input & Input distribution here */
        omp_get_wtime ();
        /* Input end here, take time */
#ifdef DEBUG
        {
            int tmp=0;
            if (iRank!=0)
                MPI_Recv(&tmp,1,MPI_INT,iRank-1,0,comm,MPI_STATUS_IGNORE);
            printf("Rank: %i\n",iRank);
            printf("localTotal: %ix%i\n",localTotalWidth,localTotalHeight);
            for (int y=0;y<localTotalHeight;y++){
                for (int x=0;x<localTotalWidth;x++)
                {
                    if (gameFieldSrc[y*localTotalWidth+x]) printf("o");
                    else printf("_");
                }
                printf("\n");
            }
            sleep(1);

            if (iRank!=(iSize-1))
                MPI_Send(&tmp,1,MPI_INT,iRank+1,0,comm);
            MPI_Barrier(comm);
        }
#endif


        unsigned long iteration;
        int nextOutput=0;
        
        int mpiRequestCounter=0;
        int maxRequestCount = 9*2; /* topLeft,top,topRight,left,right,bottomLeft,bottom,bottomRight , *2 for send and receive*/;

        MPI_Request * requestArray=(MPI_Request*)malloc(sizeof(MPI_Request)*maxRequestCount);;
        MPI_Status * statusArray=(MPI_Status*)malloc(sizeof(MPI_Status)*maxRequestCount);
        for (iteration=0;iteration<Iterations;)
        {
            /* exchange data with neighbouring fields */
            memset(requestArray,0,sizeof(MPI_Request)*maxRequestCount);
            memset(statusArray,0,sizeof(MPI_Status)*maxRequestCount);
            
            /* (-1,-1) */
            MPI_Irecv(&(gameFieldSrc[(0*haloSize+0*localPayloadHeight)*localTotalWidth+(0*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_CORNER,neighbourMatrix[0][0],8,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            MPI_Isend(&(gameFieldSrc[(1*haloSize+0*localPayloadHeight)*localTotalWidth+(1*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_CORNER,neighbourMatrix[0][0],1,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            

            /* (0,-1) */
            MPI_Irecv(&(gameFieldSrc[(0*haloSize+0*localPayloadHeight)*localTotalWidth+(1*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_ROW,neighbourMatrix[0][1],7,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            MPI_Isend(&(gameFieldSrc[(1*haloSize+0*localPayloadHeight)*localTotalWidth+(1*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_ROW,neighbourMatrix[0][1],2,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;

            /* (1,-1) */
            MPI_Irecv(&(gameFieldSrc[(0*haloSize+0*localPayloadHeight)*localTotalWidth+(1*haloSize+1*localPayloadWidth)]),
                      1,MPI_GOL_CORNER,neighbourMatrix[0][2],6,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            MPI_Isend(&(gameFieldSrc[(1*haloSize+0*localPayloadHeight)*localTotalWidth+(0*haloSize+1*localPayloadWidth)]),
                      1,MPI_GOL_CORNER,neighbourMatrix[0][2],3,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;

            /* (-1,0) */
            MPI_Irecv(&(gameFieldSrc[(1*haloSize+0*localPayloadHeight)*localTotalWidth+(0*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_COLUMN,neighbourMatrix[1][0],5,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            MPI_Isend(&(gameFieldSrc[(1*haloSize+0*localPayloadHeight)*localTotalWidth+(1*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_COLUMN,neighbourMatrix[1][0],4,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            
            /* (1,0) */
            MPI_Irecv(&(gameFieldSrc[(1*haloSize+0*localPayloadHeight)*localTotalWidth+(1*haloSize+1*localPayloadWidth)]),
                      1,MPI_GOL_COLUMN,neighbourMatrix[1][2],4,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            MPI_Isend(&(gameFieldSrc[(1*haloSize+0*localPayloadHeight)*localTotalWidth+(0*haloSize+1*localPayloadWidth)]),
                      1,MPI_GOL_COLUMN,neighbourMatrix[1][2],5,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;


            /* (-1,1) */
            MPI_Irecv(&(gameFieldSrc[(1*haloSize+1*localPayloadHeight)*localTotalWidth+(0*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_CORNER,neighbourMatrix[2][0],3,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            MPI_Isend(&(gameFieldSrc[(0*haloSize+1*localPayloadHeight)*localTotalWidth+(1*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_CORNER,neighbourMatrix[2][0],6,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            
            /* (0,1) */
            MPI_Irecv(&(gameFieldSrc[(1*haloSize+1*localPayloadHeight)*localTotalWidth+(1*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_ROW,neighbourMatrix[2][1],2,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            MPI_Isend(&(gameFieldSrc[(0*haloSize+0*localPayloadHeight)*localTotalWidth+(1*haloSize+0*localPayloadWidth)]),
                      1,MPI_GOL_ROW,neighbourMatrix[2][1],7,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;

            /* (1,1) */
            MPI_Irecv(&(gameFieldSrc[(1*haloSize+1*localPayloadHeight)*localTotalWidth+(1*haloSize+1*localPayloadWidth)]),
                      1,MPI_GOL_CORNER,neighbourMatrix[0][2],1,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;
            MPI_Isend(&(gameFieldSrc[(0*haloSize+1*localPayloadHeight)*localTotalWidth+(0*haloSize+1*localPayloadWidth)]),
                      1,MPI_GOL_CORNER,neighbourMatrix[0][2],8,comm,requestArray+mpiRequestCounter);mpiRequestCounter++;

            MPI_Waitall(mpiRequestCounter,requestArray,statusArray);mpiRequestCounter=0;
            
            /* perform local computation */
            for (int halo=0;halo<haloSize;halo++)
            {

                for (int y=halo;y<localTotalHeight-halo;y++){
                    for (int x=halo;x<localTotalWidth-halo;x++)
                    {
                        int nx,ny;
                        int livingNeighbours=0;
                        int visitedNeighbours=0;
                        for (int k=-1;k<2;k++)
                        {
                            for (int l=-1;l<2;l++)
                            {
                                nx=x+k;
                                ny=y+l;
                                // skip for the current cell
                                if (nx==x && ny==y) continue;

                                if (nx<0 || nx>=localTotalWidth ||
                                        ny<0 || ny>=localTotalHeight) 
                                {
                                    // we are a border-cell
                                    if (BOUNDRY==BOUNDRY_ALIVE) 
                                    {
                                        livingNeighbours++;
                                        continue;
                                    }
                                    else if (BOUNDRY==BOUNDRY_DEAD)
                                        continue;	
                                    else
                                    {
                                        // Periodic case: adapt n and m
                                        if (nx<0 || nx>=localTotalHeight) nx=(nx+localTotalWidth)%localTotalWidth;
                                        if (ny<0 || nx>=localTotalWidth) ny=(ny+localTotalHeight)%localTotalHeight;

                                    }
                                }
                                visitedNeighbours++;
                                if (gameFieldSrc[ny*localTotalWidth+nx]) livingNeighbours++;
                            }
                        }
                        //			printf("%i",livingNeighbours);
                        //			printf("%i",'0'+visitedNeighbours);

                        switch (livingNeighbours)
                        {
                            case 2:
                                gameFieldDst[y*localTotalWidth+x]=gameFieldSrc[y*localTotalWidth+x];
                                break;
                            case 3:
                                gameFieldDst[y*localTotalWidth+x]=1;
                                break;
                            default:
                                gameFieldDst[y*localTotalWidth+x]=0;

                        }


                    }
                }
                // swap src and dst
                gameFieldTmp=gameFieldDst;
                gameFieldDst=gameFieldSrc;
                gameFieldSrc=gameFieldTmp;

#ifdef DEBUG
                {
                    int tmp=0;
                    if (iRank!=0)
                        MPI_Recv(&tmp,1,MPI_INT,iRank-1,0,comm,MPI_STATUS_IGNORE);
                    printf("Rank: %i\n",iRank);
                    printf("localTotal: %ix%i\n",localTotalWidth,localTotalHeight);
                    for (int y=0;y<localTotalHeight;y++){
                        for (int x=0;x<localTotalWidth;x++)
                        {
                            if (gameFieldSrc[y*localTotalWidth+x]) printf("o");
                            else printf("_");
                        }
                        printf("\n");
                    }
                    sleep(1);
                    if (iRank!=(iSize-1))
                        MPI_Send(&tmp,1,MPI_INT,iRank+1,0,comm);
                    MPI_Barrier(comm);
                }
#endif 
                // Is the current time step in the output list?
                if (nextOutput < NumberOfOutputIterations && OutputIterations[nextOutput]==iteration)
                {
                    char *outputName;
                    if (iRank==0){
                        outputName=(char*)malloc(strnlen(OutputFileNameBase,512)+10);
                        sprintf(outputName,"%s.%i.cgolf",OutputFileNameBase,iteration);
                    }
                    writeGOLData(&cgolf,outputName,globalWidth,globalHeight,localBaseWidth,localBaseHeight,haloSize,gameFieldSrc,
                            rowOversizeCount,columnOversizeCount,widthBlockCount,heightBlockCount,comm);
                    nextOutput++;
                }
                if (iteration>=Iterations)
                    break;
                else
                    iteration++;
            }



        }
        /* Final result: has to be done ALLWAYS! */
        {
            char *outputName;
                    if (iRank==0){
            outputName=(char*)malloc(strnlen(OutputFileNameBase,512)+10);
            sprintf(outputName,"%s.end.cgolf",OutputFileNameBase);
                    }
            writeGOLData(&cgolf,outputName,globalWidth,globalHeight,localBaseWidth,localBaseHeight,haloSize,gameFieldSrc,
                    rowOversizeCount,columnOversizeCount,widthBlockCount,heightBlockCount,comm);
        }
    } /* iRank < iSize */
    else
    {
        printf("Process %i remains idle\n",iRank);
    }

    /* create custom communicator */


    /* create management structure */


    ;




    /* MPI DONE, Program about to finish */
    MPI_Comm_free(&comm);	
    MPI_Finalize();
    return 0;
}





