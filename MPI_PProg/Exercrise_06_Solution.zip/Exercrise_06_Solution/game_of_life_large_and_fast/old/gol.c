#define _LARGEFILE64_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <assert.h>
#include <omp.h>
#include <mpi.h>
#ifdef DEBUG
#define ON_DEBUG(x) x
#else
#define ON_DEBUG(x) 
#endif

#include <unistd.h>
#include <sys/types.h>
       #include <sys/stat.h>
       #include <fcntl.h>

typedef enum {BOUNDRY_ALIVE=1,
	      BOUNDRY_DEAD=2,
	      BOUNDRY_PERIODIC=3} boundryType;

#ifndef BOUNDRY_TYPE
const boundryType BOUNDRY=BOUNDRY_DEAD;
#else
const boundryType BOUNDRY=BOUNDRY_TYPE;
#endif	
#define _FILE_OFFSET_BITS 64

__inline int imin(int a,int b)
{
	return a<b?a:b;
};

typedef struct {
	unsigned char status[2];} cell;




/* the file consists of N cells, 1 newline char, and M rows of such structore follwed by EOF*//*
unsigned char readInputFile(FILE * file,int N,int M,int n,int m)
{
	unsigned char cell;
	int bytesRead;
	lseek64(file,n*(M+1)+m,SEEK_SET);
	fread(&cell,1,1,file);
	if (cell=='l' || cell=='o' || cell=='1')return 1;
	else return 0;
};
void writeOutputFile(FILE * file,int N,int M,int n,int m, unsigned char status)
{
	unsigned char cell;
	int bytesRead;
  	off64_t offset=n*(M+1)+m;
	lseek64(file,n*(M+1)+m,SEEK_SET);
	if (n<0 || n>N || m<0 || m>M)
{
	fprintf(stderr,"OutOfBoundryException in writeOutputFile\n\tN=%i M=%i n=%i m=%i\n\t offset=%li\n",N,M,n,m,offset);
	exit(-1);
}
	if (status!=0)
		cell='o';
	else
		cell=' ';
	fwrite(&cell,1,1,file);
	return;
};*/
unsigned char readInputFile(FILE * file,int N,int M,int n,int m,char fileType)
{
	unsigned char cell;
	off64_t offset;
	if (fileType=='h')
	{
		offset=n*(M+1)+m;	
	}
	else 
	{
		/* machine format */
		offset=n*M+m;	
	}
	fseek(file,offset,SEEK_SET);
	fread(&cell,1,1,file);
	if (cell=='l' || cell=='o' || cell=='1')return 1;
	else return 0;
};
void writeOutputFile(FILE * file,int N,int M,int n,int m, unsigned char status,char fileType)
{
	int blocksToWrite=1;
	unsigned char cell[2];
	off64_t offset;
	if (fileType=='h')
	{
		offset=n*(M+1)+m;
		if (status!=0)
			cell[0]='o';
		else
			cell[0]=' ';
		if (m==(M-1))
		{
			cell[1]='\n';		
			blocksToWrite=2;
		}
	}
	else 
	{
		/* machine format */
		offset=n*M+m;	
		if (status!=0)
			cell[0]='1';
		else
			cell[0]='0';

	}
	fseek(file,offset,SEEK_SET);
	if (n<0 || n>N || m<0 || m>M)
	{
		fprintf(stderr,"OutOfBoundryException in writeOutputFile\n\tN=%i M=%i n=%i m=%i\n\t offset=%li\n",N,M,n,m,offset);
		exit(-1);
	}
	fwrite(cell,blocksToWrite,1,file);
	return;
};

void writeOutputFile2(int file,int N,int M,int n,int m, unsigned char status,char fileType)
{
	int blocksToWrite=1;
	unsigned char cell[2];
	off64_t offset;
	if (fileType=='h')
	{
		offset=n*(M+1)+m;
		if (status!=0)
			cell[0]='o';
		else
			cell[0]=' ';
		if (m==(M-1))
		{
			cell[1]='\n';		
			blocksToWrite=2;
		}
	}
	else 
	{
		/* machine format */
		offset=n*M+m;	
		if (status!=0)
			cell[0]='1';
		else
			cell[0]='0';

	}
	lseek64(file,offset,SEEK_SET);
	if (n<0 || n>N || m<0 || m>M)
	{
		fprintf(stderr,"OutOfBoundryException in writeOutputFile\n\tN=%i M=%i n=%i m=%i\n\t offset=%li\n",N,M,n,m,offset);
		exit(-1);
	}
	int bytesWritten=write(file,cell,blocksToWrite);
	if (bytesWritten!=blocksToWrite)
		perror ("IO ISSUE");
	return;
};


int main(int argc, char ** argv)
{
	int N,M,Iterations,NumberOfOutputIterations;
	int OutputCounter;
	char *InputFileName;
	int* OutputIterations=NULL;
	double StartTime,EndTime;
	/* Start MPI */
	MPI_Init(&argc,&argv);
	int ompMaxThreadCount=omp_get_max_threads();
	{ /* YOU DO NOT NEED TO MODIFY: Begin */
		int i;
		/* Process Input from command-line arguments */
		if (argc< 5)
			fprintf(stderr,"gol N M InputFile TotalIt NumOut It1 It2 ... It(NumOut)\n\tN,M: 100 ... 2^20\n\tInputfile: ASCII-encoded game filed, NxM elements, '0'=dead, '1'=alive\n\t TotalIt: Number of total iterations\n\t NumOut: Number of output-times\n\t It1 ... It(NumOut): NumOut-iteration times for output\n");

//		printf("argv[0]=%s,argv[1]=%s\n",argv[0],argv[1]);
		N=atoi(*++argv);
		M=atoi(*++argv);
		InputFileName=*++argv;
		Iterations=atoi(*++argv);
		NumberOfOutputIterations=atoi(*++argv);
//		printf("NumberOfOutputIterations=%i\n",NumberOfOutputIterations);

		if (NumberOfOutputIterations<0 || (OutputIterations=(int*)malloc(sizeof(int)*NumberOfOutputIterations))==NULL)
		{
//			fprintf(stderr,"Error: could not allocate output-time array. NumOut < 0 or out of memory.\n");		
			return -1;
		}
		else
		{
			OutputCounter=0;
			while(OutputCounter<NumberOfOutputIterations)
			{	

				OutputIterations[OutputCounter++]=atoi(*++argv);
			}
		}
		OutputIterations[OutputCounter++]=Iterations;

//		printf("\tDomain: %i x %i (N x M)\n\tInputfile: %s\n\tIterations=%i\n",N,M,InputFileName,Iterations);
//		for (i=0;i<NumberOfOutputIterations;i++)
//			printf("\tOutput after %i iterations\n",OutputIterations[i]);
//		printf("\tOutput after %i iterations\n",Iterations);
	} /* YOU DO NOT NEED TO MODIFY: End */


	/* prepare game */
	int rank, numProc;
	MPI_Comm_size(MPI_COMM_WORLD,&numProc);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);

	int domainRowOffset,
	    domainColumnOffset,
	    localDomainRowCount,
	    localDomainColumnCount;
	int haloSize=2;
	
	int rowBlocks,
	    columnBlocks;

	/* Compute partitioning */
	rowBlocks=numProc;
	columnBlocks=1;
	while (rowBlocks>columnBlocks && rowBlocks%2==0)
	{
		columnBlocks*=2;
		rowBlocks/=2;
	}
	printf("Domain (%i x %i) partitioned in %i columns and %i rows\n",N,M,columnBlocks,rowBlocks);
	
	int rowBlockNumber,columnBlockNumber;
	rowBlockNumber=(rank%rowBlocks);
	columnBlockNumber=(rank/rowBlocks);
	printf("%i\trow=%i,column=%i\n",rank,rowBlockNumber,columnBlockNumber);
	

	domainRowOffset=(N/rowBlocks)*(rank%rowBlocks);
	domainColumnOffset=(M/columnBlocks)*(rank/rowBlocks);
	ON_DEBUG(printf("%i\tLocal offset: (%i,%i)\n",rank,domainRowOffset,domainColumnOffset);)

	localDomainRowCount=imin(M,(M*(rowBlockNumber+1)/rowBlocks))-(M*rowBlockNumber/rowBlocks)+2*haloSize;
	localDomainColumnCount=imin(N,(N*(columnBlockNumber+1)/columnBlocks))-(N*columnBlockNumber/columnBlocks)+2*haloSize;

	ON_DEBUG(printf("%i\tlocal domain size: %i x %i (incl ghostcells for a halo of %i)\n",rank,localDomainRowCount,localDomainColumnCount,haloSize);)

		/* Compute neighbouring ranks */	
		int nextColBlockRank,prevColBlockRank,nextRowBlockRank,prevRowBlockRank;
	int prevRowPrevColBlockRank, prevRowNextColBlockRank,nextRowPrevColBlockRank,nextRowNextColBlockRank;
	int NWRowOffset,NWColumnOffset,	
		NERowOffset,NEColumnOffset,
		SERowOffset,SEColumnOffset,
		SWRowOffset,SWColumnOffset;

	NWRowOffset=NERowOffset=SERowOffset=SWRowOffset=NWColumnOffset=NEColumnOffset=SEColumnOffset=SWColumnOffset=-99;
	if (rowBlockNumber-1<0)
	{
		prevRowPrevColBlockRank=MPI_PROC_NULL;
		prevRowBlockRank=MPI_PROC_NULL;
		prevRowNextColBlockRank=MPI_PROC_NULL;

		/* we possibly need to copy from the left or right sides, if top is not populated */
		if ((columnBlockNumber-1)>=0)
		{	
			prevRowPrevColBlockRank=rank-rowBlocks;
			NWRowOffset=0;NWColumnOffset=1;
		}
		if (columnBlockNumber+1<columnBlocks)
		{
			prevRowNextColBlockRank=rank+rowBlocks;
			NERowOffset=0;NEColumnOffset=-1;
		}
	}
	else 
	{
		if ((columnBlockNumber-1)<0)
		{
			prevRowPrevColBlockRank=rank-1;
			NWRowOffset=1;NWColumnOffset=0;
		}
		else
		{
			prevRowPrevColBlockRank=rank-1-rowBlocks;
			NWRowOffset=1;NWColumnOffset=1;

		}
		prevRowBlockRank=rank-1;

		if (columnBlockNumber+1>=columnBlocks)
		{
			prevRowNextColBlockRank=rank-1;
			NERowOffset=1;NEColumnOffset=0;
		}
		else
		{
			prevRowNextColBlockRank=rank-1+rowBlocks;;
			NERowOffset=1;NEColumnOffset=-1;
		}
	}


	if (rowBlockNumber+1>=rowBlocks) 
	{
		nextRowPrevColBlockRank=MPI_PROC_NULL;
		nextRowBlockRank=MPI_PROC_NULL;
		nextRowNextColBlockRank=MPI_PROC_NULL;
		if ((columnBlockNumber-1)>=0)
		{
			nextRowPrevColBlockRank=rank-rowBlocks;
			SWRowOffset=0;SWColumnOffset=1;
		}
		if (columnBlockNumber+1<columnBlocks)
		{
			nextRowNextColBlockRank=rank+rowBlocks;
			SERowOffset=0;SEColumnOffset=-1;
		}
	}
	else 
	{
		if (columnBlockNumber-1<0) 
		{
			nextRowPrevColBlockRank=rank+1;
			SWRowOffset=-1;SWColumnOffset=0;
		}
		else
		{
			nextRowPrevColBlockRank=rank+1-rowBlocks;
			SWRowOffset=-1;SWColumnOffset=1;
		}
		nextRowBlockRank=rank+1;
		if (columnBlockNumber+1>=columnBlocks)
		{
			nextRowNextColBlockRank=rank+1;
			SERowOffset=-1;SEColumnOffset=0;

		}
		else
		{
			nextRowNextColBlockRank=rank+1+rowBlocks;
			SERowOffset=-1;SEColumnOffset=-1;
		}	
	}
	if (columnBlockNumber-1<0) prevColBlockRank=MPI_PROC_NULL;
	else prevColBlockRank=rank-rowBlocks;
	if (columnBlockNumber+1>=columnBlocks) nextColBlockRank=MPI_PROC_NULL;
	else nextColBlockRank=rank+rowBlocks;
	
	assert(NWRowOffset!=99 && NERowOffset!=99 && SERowOffset!=99 && SWRowOffset !=99 && NWColumnOffset!=99 && NEColumnOffset !=99 && SEColumnOffset != 99 && SWColumnOffset !=99);
	
	ON_DEBUG({int ranks;for(ranks=0;ranks<numProc;ranks++){if (rank==ranks)printf ("%i\t%2i %2i %2i\n\t%2i %2i %2i\n\t%2i %2i %2i\n",rank,prevRowPrevColBlockRank,prevRowBlockRank,prevRowNextColBlockRank,prevColBlockRank,rank ,nextColBlockRank,nextRowPrevColBlockRank,nextRowBlockRank,nextRowNextColBlockRank);MPI_Barrier(MPI_COMM_WORLD);}})
	MPI_Barrier(MPI_COMM_WORLD);	
	int row,column;	

	/* allocate domain */
	cell * cellBuffer;
	cell ** localDomain;
	cell * lDMin,*lDMax;

	cellBuffer=(cell*)malloc(sizeof(cell)*localDomainColumnCount*localDomainRowCount);
	if (cellBuffer==NULL) MPI_Abort(MPI_COMM_WORLD,-2);
	localDomain=(cell*)malloc(sizeof(cell*)*localDomainRowCount);
	if (localDomain==NULL) MPI_Abort(MPI_COMM_WORLD,-2);
	for (row=0;row<localDomainRowCount;row++)	
	  localDomain[row]=cellBuffer+localDomainColumnCount*row;
	lDMin=cellBuffer;
	lDMax=cellBuffer+localDomainColumnCount*localDomainRowCount;
			


	/* read the input */

	if (BOUNDRY!=BOUNDRY_PERIODIC)
{
		if (BOUNDRY==BOUNDRY_DEAD) memset(cellBuffer,0,sizeof(cell)*localDomainColumnCount*localDomainRowCount);
		if (BOUNDRY==BOUNDRY_ALIVE) memset(cellBuffer,1,sizeof(cell)*localDomainColumnCount*localDomainRowCount);	
}
	//	memset(cellBuffer,rank,sizeof(cell)*localDomainColumnCount*localDomainRowCount);	

	FILE *fileHandle;
	fileHandle=fopen(InputFileName,"r");
	for (row=haloSize;row<(localDomainRowCount-haloSize);row++)
{	
		for (column=haloSize;column<(localDomainColumnCount-haloSize);column++)
{	
		int cellStatus=readInputFile(fileHandle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize,'m');
		if (cellStatus)		printf("o");
		else (printf(" "));
		localDomain[row][column].status[0]=cellStatus;
//readInputFile(fileHandle,N,M,domainRowOffset+row,domainColumnOffset+column,'m');
}
	printf("\n");
}
	fclose(fileHandle);
	/* create MPI Data-types for commuication */
	MPI_Datatype	haloPrevRowPrevCol,
			haloPrevCol,
			haloPrevRowNextCol,
			haloPrevRow,
			haloNextRow,
			haloNextRowPrevCol,
			haloNextRowNextCol;
/*
	int MPI_Type_indexed(
               int count,
               int blocklens[],
               int indices[],
               MPI_Datatype old_type,
               MPI_Datatype *newtype )
*/
/*	MPI_Type_indexed(haloSize, */
	
	
	int nextOutput=0;
	/* start time measurement */
	StartTime = omp_get_wtime ( );
	/* implement your program here */		
	int timeStep=0,subStep=0;
	
	int maxRequestCount = 9; /* topLeft,top,topRight,left,right,bottomLeft,bottom,bottomRight*/;
	MPI_Request * recvRequestArray;
	MPI_Request * sendRequestArray;
	MPI_Status  * sendStatusArray;
	MPI_Status  * recvStatusArray;
	recvRequestArray=(MPI_Request*)malloc(sizeof(MPI_Request)*maxRequestCount);
	sendRequestArray=(MPI_Request*)malloc(sizeof(MPI_Request)*maxRequestCount);
	recvStatusArray=(MPI_Status*)malloc(sizeof(MPI_Status)*maxRequestCount);
	sendStatusArray=(MPI_Status*)malloc(sizeof(MPI_Status)*maxRequestCount);
		

	MPI_Datatype CELLTYPE,
		     HALO_CORNERTYPE,
		     HALO_ROWTYPE,
		     HALO_COLUMNTYPE;
#ifdef C_LIKE_STRUCT		
	int CellType_BlockLengths[4]={1,1,1,1}
	int CellTypeOffsets[4]={0,0,1,1};
	MPI_Type CellTypeTypes[4]={MPI_LB,MPI_CHAR,MPI_CHAR,MPI_UB};
	MPI_Type_struct(4,CellType_BlockLengths,CellTypeOffsets,CellTypeTypes,&CELLTYPE);
#else
	MPI_Type_vector(1,2,1,MPI_CHAR,&CELLTYPE);
#endif
	MPI_Type_commit(&CELLTYPE);


//	MPI_Type_vector((localDomainColumnCount-(2*haloSize)),haloSize,localDomainColumnCount,CELLTYPE,&HALO_COLUMNTYPE);
	MPI_Type_vector((localDomainRowCount-(2*haloSize)),haloSize,localDomainColumnCount,CELLTYPE,&HALO_COLUMNTYPE);
	printf("MPI_Type_vector(%i,%i,%i,...)\n",(localDomainRowCount-(2*haloSize)),haloSize,localDomainColumnCount);
	MPI_Type_commit(&HALO_COLUMNTYPE);


	MPI_Type_vector(haloSize,haloSize,localDomainColumnCount,CELLTYPE,&HALO_CORNERTYPE);
	MPI_Type_commit(&HALO_CORNERTYPE);


//FAULTY	MPI_Type_vector((localDomainColumnCount-2*haloSize)*haloSize,(localDomainColumnCount-2*haloSize),localDomainColumnCount,CELLTYPE,&HALO_ROWTYPE);
	MPI_Type_vector(haloSize,(localDomainColumnCount-2*haloSize),localDomainColumnCount,CELLTYPE,&HALO_ROWTYPE);
	MPI_Type_commit(&HALO_ROWTYPE);

	int requestCounter=0;
	/* Tags:
		123
                4 5
                678*/

	printf("Rank %i: Starting game of life\n",rank);	
	ON_DEBUG(int alternateRequestCounter=0;)	
	for (timeStep=0;timeStep<Iterations;timeStep+=haloSize)
	{
		memset(recvRequestArray,0,sizeof(MPI_Request)*maxRequestCount);
		memset(sendRequestArray,0,sizeof(MPI_Request)*maxRequestCount);
		/* exchange halo */
		/* simple exchange, no direct opmitization */
		requestCounter=0;
		/* prevRowPrevCol Halo-Exchange */
		MPI_Irecv(&(localDomain[0][0]),1,HALO_CORNERTYPE,								prevRowPrevColBlockRank,		1,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		MPI_Isend(&(localDomain[NWRowOffset*haloSize][NWColumnOffset*haloSize]),1,HALO_CORNERTYPE,prevRowPrevColBlockRank,1,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		requestCounter++;

		/* prevRwo Halo-Exchange */
		MPI_Irecv(&(localDomain[0][haloSize]),1,HALO_ROWTYPE,							prevRowBlockRank,				2,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		MPI_Isend(&(localDomain[haloSize][haloSize]),1,HALO_ROWTYPE,					prevRowBlockRank,				2,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		requestCounter++;

		/* prevRowNextCol */ 
		MPI_Irecv(&(localDomain[0][localDomainColumnCount-haloSize]),1,HALO_CORNERTYPE,	prevRowNextColBlockRank,		1,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		MPI_Isend(&(localDomain[NERowOffset*haloSize][localDomainColumnCount-haloSize+NEColumnOffset*haloSize]),1,HALO_CORNERTYPE,prevRowNextColBlockRank,1,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		requestCounter++;

		/* left and right are a bit more difficult, as they are not consecutive */
		MPI_Irecv(&(localDomain[haloSize][0]),1,HALO_COLUMNTYPE,						prevColBlockRank,				3,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		MPI_Isend(&(localDomain[haloSize][haloSize]),1,HALO_COLUMNTYPE,					prevColBlockRank,				3,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		requestCounter++;

		MPI_Irecv(&(localDomain[haloSize][localDomainColumnCount-haloSize]),1,
																		HALO_COLUMNTYPE,nextColBlockRank,				3,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		MPI_Isend(&(localDomain[haloSize][localDomainColumnCount-2*haloSize]),1,
																		HALO_COLUMNTYPE,nextColBlockRank,				3,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		requestCounter++;

		/* prevRowNextCol */ 
		MPI_Irecv(&(localDomain[localDomainRowCount-haloSize][0]),1,HALO_CORNERTYPE,	nextRowPrevColBlockRank,		1,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		MPI_Isend(&(localDomain[localDomainRowCount-haloSize+SWRowOffset*haloSize][localDomainColumnCount-haloSize+SWColumnOffset*haloSize]),1,
																	HALO_CORNERTYPE,	nextRowPrevColBlockRank,		1,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		requestCounter++;
		
		/* prevRwo Halo-Exchange */
		MPI_Irecv(&(localDomain[localDomainRowCount-haloSize][haloSize]),1,HALO_ROWTYPE,
																						nextRowBlockRank,				2,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		MPI_Isend(&(localDomain[localDomainRowCount-2*haloSize][haloSize]),1,
																		HALO_ROWTYPE,	nextRowBlockRank,				2,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		requestCounter++;

		/* bottom is easy again */
		/* nextRowPrevCol Halo-Exchange */
		MPI_Irecv(&(localDomain[localDomainRowCount-haloSize][localDomainColumnCount-haloSize]),1,HALO_CORNERTYPE,
																						nextRowNextColBlockRank,		1,MPI_COMM_WORLD,recvRequestArray+requestCounter);
		MPI_Isend(&(localDomain[localDomainRowCount-haloSize+SERowOffset*haloSize][localDomainColumnCount-haloSize+SEColumnOffset*haloSize]),1,HALO_CORNERTYPE,
																						nextRowNextColBlockRank,		1,MPI_COMM_WORLD,sendRequestArray+requestCounter);
		requestCounter++;

//		ON_DEBUG(printf("Rank #%i entering waitall\n",rank);int waitNotDone=1,completed;while(waitNotDone){MPI_Waitany(requestCounter,recvRequestArray,&completed,recvStatusArray);if (completed==MPI_UNDEFINED) waitNotDone=0;	else 	printf("Rank %i: recv operation #%i completed\n",rank,completed);		})
		MPI_Waitall(requestCounter,recvRequestArray,recvStatusArray);
		MPI_Waitall(requestCounter,sendRequestArray,sendStatusArray);requestCounter=0;
		/* first wait for the receives */
		printf("Waitall\n");MPI_Waitall(requestCounter,recvRequestArray,recvStatusArray);MPI_Waitall(requestCounter,sendRequestArray,sendStatusArray);requestCounter=0;
		/* compute game */

		for (subStep=0;subStep<haloSize && (subStep+timeStep) <Iterations;subStep++)
		{
			for (row=1+subStep;row<(localDomainRowCount-(1+subStep));row++)
			{	
				for (column=1+subStep;column<(localDomainColumnCount-(1+subStep));column++)
				{
					int COLUMN=domainColumnOffset+column-haloSize;
					int ROW=domainRowOffset+row-haloSize;
					// leave the boudaries untouched for non-periodic bondaries
					if (BOUNDRY!=BOUNDRY_PERIODIC && (ROW<0||ROW>=N ||COLUMN<0||COLUMN>=M)) continue;
					int livingNeightbours=0;
					
					livingNeightbours+=localDomain[row-1][column-1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row-1][column-0].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row-1][column+1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row-0][column-1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row-0][column+1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row+1][column-1].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row+1][column-0].status[(timeStep+subStep)%2];
					livingNeightbours+=localDomain[row+1][column+1].status[(timeStep+subStep)%2];
		//			ON_DEBUG(printf("Neighbours Cell(%i,%i)=%i\tGlobalCoords(%i,%i)\n",row,column,livingNeightbours,ROW,COLUMN);)
					if (livingNeightbours==3) localDomain[row][column].status[(timeStep+subStep+1)%2]=1;
					else if (livingNeightbours==2) localDomain[row][column].status[(timeStep+subStep+1)%2]=localDomain[row][column].status[(timeStep+subStep)%2];
					else localDomain[row][column].status[(timeStep+subStep+1)%2]=0;		
				}	
			}
			
			if (nextOutput < NumberOfOutputIterations && OutputIterations[nextOutput]==(timeStep+subStep+1))
			{
				/* output here */
				nextOutput++;	
				char *outputName;
				outputName=(char*)malloc(1024);
				sprintf(outputName,"%s.%i.txt",InputFileName,nextOutput);
				printf("Rank %i: Starting output\n",rank);
				/*write*/
				int handle;	
				if (rank==0)
				{
//					fileHandle=fopen(outputName,"w+");
					handle=open(outputName,O_CREAT|O_LARGEFILE|O_RDWR,S_IWUSR|S_IRUSR);
					//					handle=open("outputName",
					/* write */
					for (row=haloSize;row<(localDomainRowCount-haloSize);row++)
					{
						for (column=haloSize;column<(localDomainColumnCount-haloSize);column++)
						{	
							if (localDomain[row][column].status[(timeStep+subStep+1)%2])
								printf("o");
							else printf(" ");
					
							writeOutputFile2(handle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize, localDomain[row][column].status[(timeStep+subStep+1)%2],'h');
						//	writeOutputFile(fileHandle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize, localDomain[row][column].status[(timeStep+subStep+1)%2],'h');
						}
						printf("\n");
					}
						close(handle);
//					fclose(fileHandle);
					if (numProc>1)		
						MPI_Send(NULL,0,MPI_CHAR,1,0,MPI_COMM_WORLD);
				}
				else
				{	
					MPI_Recv(NULL,0,MPI_CHAR,rank-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
					handle=open(outputName,O_CREAT|O_LARGEFILE|O_RDWR,S_IRUSR|S_IWUSR);
					//					handle=open("outputName",
					/* write */
					for (row=haloSize;row<(localDomainRowCount-haloSize);row++)
					{
						for (column=haloSize;column<(localDomainColumnCount-haloSize);column++)
						{	
							if (localDomain[row][column].status[(timeStep+subStep+1)%2])
								printf("o");
							else printf(" ");
					
							writeOutputFile2(handle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize, localDomain[row][column].status[(timeStep+subStep+1)%2],'h');
						//	writeOutputFile(fileHandle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize, localDomain[row][column].status[(timeStep+subStep+1)%2],'h');
						}
						printf("\n");
					}
						close(handle);
					if ((rank+1)<numProc)
						MPI_Send(NULL,0,MPI_CHAR,rank+1,0,MPI_COMM_WORLD);
				}
				MPI_Barrier(MPI_COMM_WORLD);
			}
		}
	}
	/* stop time measurement */
	EndTime = omp_get_wtime();
	
	/* write the data after the last iteration to disk */
	if (rank==0) printf("Starting final output\n");
				printf("Rank %i: Starting output\n",rank);
				/* output here */
				nextOutput++;	
				char *outputName;
				outputName=(char*)malloc(1024);
				sprintf(outputName,"%s.end.txt",InputFileName,nextOutput);
				/*write*/
				int handle;	
				if (rank==0)
				{
//					fileHandle=fopen(outputName,"w+");
					handle=open(outputName,O_CREAT|O_LARGEFILE|O_RDWR,S_IWUSR|S_IRUSR);
					//					handle=open("outputName",
					/* write */
					for (row=haloSize;row<(localDomainRowCount-haloSize);row++)
					{
						for (column=haloSize;column<(localDomainColumnCount-haloSize);column++)
						{	
							if (localDomain[row][column].status[(timeStep+subStep+1)%2])
								printf("o");
							else printf(" ");
					
							writeOutputFile2(handle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize, localDomain[row][column].status[(timeStep+subStep+1)%2],'h');
						//	writeOutputFile(fileHandle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize, localDomain[row][column].status[(timeStep+subStep+1)%2],'h');
						}
						printf("\n");
					}
						close(handle);
//					fclose(fileHandle);
					if (numProc>1)		
						MPI_Send(NULL,0,MPI_CHAR,1,0,MPI_COMM_WORLD);
				}
				else
				{	
					MPI_Recv(NULL,0,MPI_CHAR,rank-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
					handle=open(outputName,O_CREAT|O_LARGEFILE|O_RDWR,S_IRUSR|S_IWUSR);
					//					handle=open("outputName",
					/* write */
					for (row=haloSize;row<(localDomainRowCount-haloSize);row++)
					{
						for (column=haloSize;column<(localDomainColumnCount-haloSize);column++)
						{	
							if (localDomain[row][column].status[(timeStep+subStep+1)%2])
								printf("o");
							else printf(" ");
					
							writeOutputFile2(handle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize, localDomain[row][column].status[(timeStep+subStep+1)%2],'h');
						//	writeOutputFile(fileHandle,N,M,domainRowOffset+row-haloSize,domainColumnOffset+column-haloSize, localDomain[row][column].status[(timeStep+subStep+1)%2],'h');
						}
						printf("\n");
					}
						close(handle);
					if ((rank+1)<numProc)
						MPI_Send(NULL,0,MPI_CHAR,rank+1,0,MPI_COMM_WORLD);
				}
				MPI_Barrier(MPI_COMM_WORLD);

	

	MPI_Finalize();
	return 0;

}

