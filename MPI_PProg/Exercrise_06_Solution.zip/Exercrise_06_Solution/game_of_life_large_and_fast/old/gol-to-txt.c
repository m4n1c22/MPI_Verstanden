#define _LARGEFILE64_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#ifdef DEBUG
#define ON_DEBUG(x) x
#else
#define ON_DEBUG(x) 
#endif

typedef enum {BOUNDRY_ALIVE=1,
	      BOUNDRY_DEAD=2,
	      BOUNDRY_PERIODIC=3} boundryType;

#ifndef BOUNDRY_TYPE
const boundryType BOUNDRY=BOUNDRY_DEAD;
#else
const boundryType BOUNDRY=BOUNDRY_TYPE;
#endif	
#define _FILE_OFFSET_BITS 64

__inline int imin(int a,int b)
{
	return a<b?a:b;
};

typedef struct {
	unsigned char status[2];} cell;

/* the file consists of N cells, 1 newline char, and M rows of such structore follwed by EOF*/
unsigned char readInputFile(FILE * file,int N,int M,int n,int m,char fileType)
{
	unsigned char cell;
	off64_t offset,realizedOffset;
	if (fileType=='h')
	{
		offset=n*(M+1)+m;	
	}
	else 
	{
		/* machine format */
		offset=n*M+m;	
	}
	realizedOffset=fseek(file,offset,SEEK_SET);
	if (realizedOffset<0) perror("fatal error in lseek64");
	fread(&cell,1,1,file);
	printf("NxM=%ix%i, m=%i n=%i,offset = %i , >%c< = %i\n",N,M,n,m,realizedOffset,cell,cell);
	if (cell=='l' || cell=='o' || cell=='1')return 1;
	else return 0;
};

void writeOutputFile(FILE * file,int N,int M,int n,int m, unsigned char status,char fileType)
{
	int blocksToWrite=1;
	unsigned char cell[2];
	off64_t offset;
	if (fileType=='h')
	{
		offset=n*(M+1)+m;
		if (status!=0)
			cell[0]='o';
		else
			cell[0]=' ';
		if (m==(M-1))
		{
			cell[1]='\n';		
			blocksToWrite=2;
		}
	}
	else 
	{
		/* machine format */
		offset=n*M+m;	
		if (status!=0)
			cell[0]='1';
		else
			cell[0]='0';
		
	}
	fseek(file,offset,SEEK_SET);
	if (n<0 || n>N || m<0 || m>M)
{
	fprintf(stderr,"OutOfBoundryException in writeOutputFile\n\tN=%i M=%i n=%i m=%i\n\t offset=%li\n",N,M,n,m,offset);
	exit(-1);
}
	fwrite(cell,1,blocksToWrite,file);
	return;
};


int main(int argc, char ** argv)
{
	int N,M,Iterations,NumberOfOutputIterations;
	int OutputCounter;
	char *InputFileName;
	char *OutputFileName;
	int* OutputIterations=NULL;
	double StartTime,EndTime;
	/* Start MPI */
	{ /* YOU DO NOT NEED TO MODIFY: Begin */
		int i;
		/* Process Input from command-line arguments */
		N=atoi(*++argv);
		M=atoi(*++argv);
		InputFileName=*++argv;
		OutputFileName=*++argv;
	} /* YOU DO NOT NEED TO MODIFY: End */
	int row,column;

	printf("Converting machine-readable GOL-File to Human-Readable: %ix%i  %s -> %s\n",N,M,InputFileName,OutputFileName);

	FILE *inputFileHandle,*outputFileHandle;
	inputFileHandle=fopen(InputFileName,"r");
	outputFileHandle=fopen(OutputFileName,"w");
	for (row=0;row<N;row++)
	{	
		for (column=0;column<M;column++)
		{
//			int state=readInputFile(inputFileHandle,N,M,row,column,'h');
//			if (state) printf("o");
//			else printf("_");
			writeOutputFile(outputFileHandle,N,M,row,column,readInputFile(inputFileHandle,N,M,row,column,'m'),'h');
		}
		printf("\n");
	}
	fclose(outputFileHandle);
	fclose(inputFileHandle);
	return 0;
}
