#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <math.h>
#define IDLETIME 0.1
#define true 1

double realtime (void) {
  struct timeval tv;
  gettimeofday(&tv, (struct timezone*)0);
  return ((double)tv.tv_sec + (double)tv.tv_usec / 1000000.0 );
}


double function(double x)
{
//	double t=realtime();
//	while(realtime()-t <= IDLETIME*x*x);
	return 4.0 / (1.0+x*x);
}




double integral_master(double (*function)(double x),double x_start,double x_end,int maxSteps)
{
	int iMyRank,iNumProcs;
	MPI_Comm_rank(MPI_COMM_WORLD,&iMyRank);
	MPI_Comm_size(MPI_COMM_WORLD,&iNumProcs);

	double sum=0.0,partSum;
	double x[2],y[2];

	MPI_Status status;
	MPI_Request request;
	int i;
	int sentWorkPackages=0;
	int *isWorking=(int*)malloc(sizeof(int)*iNumProcs);
	for (i=0;i<iNumProcs;i++)
		isWorking[i]=0;
	double stepSize=(x_end-x_start)/(double)maxSteps;
	int step;
	int nextRank=1;

	int setp;

	/* I am the master, distribute the work */

	/* send initial work */

//	printf("Computing with %i supporting points\n",maxSteps);
	int stride=(maxSteps)/(iNumProcs-1);
//	printf("Stride is %i\n",stride);
	int iTargetRank;
	step=1;
	int openMessageCount=0;
	while(step<=maxSteps)
	{
//		printf("Processing block\n");
		for (iTargetRank=1;step<=maxSteps && iTargetRank<iNumProcs;iTargetRank++)
		{

//			printf("\n\nRank %i is doing following work\n",iTargetRank);
			double startX=(x_start+((double)step-0.5)*(x_end-x_start))/maxSteps;
			double delta=(x_end-x_start)/maxSteps;

//			printf("Start support point %f\n",startX);
//			printf("Step width %f\n",delta);
//			printf("Number of elements %i\n",stride);
			MPI_Send(&startX,1,MPI_DOUBLE,iTargetRank,0,MPI_COMM_WORLD);
			MPI_Send(&stride,1,MPI_INT,iTargetRank,0,MPI_COMM_WORLD);
			MPI_Send(&delta,1,MPI_DOUBLE,iTargetRank,0,MPI_COMM_WORLD);
//			for (i=0;i<stride;i++)
//				printf("Computing %f\n",startX+i*delta);
			step+=stride;
			openMessageCount++;
		}		
		for (iTargetRank=1;iTargetRank<(1+openMessageCount);iTargetRank++)
		{
			MPI_Recv(&partSum,1,MPI_DOUBLE,iTargetRank,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			sum+=partSum;
		}
		openMessageCount=0;
		/* after the first for loop has completed we have just the leftover-steps left to compute */
		stride=1;
	}
//	if (step<=maxSteps)
//	{
//		printf("Leftover steps: %i\n",maxSteps-(step-1));
//		
//		
//	}
	for (nextRank=1;nextRank<iNumProcs;nextRank++)
		MPI_Send(&nextRank,0,MPI_INT,nextRank,2,MPI_COMM_WORLD);
	return sum/(double)maxSteps;
//	for (step=1;step<maxSteps;step
#if 0
	
	for (step=0;step<maxSteps;step++)
	{

		int stepIsSend=0;
		/* find the first idle process */
		for (i=1;i<iNumProcs;i++)
		{
			/* if the process is not working*/
			if (isWorking[i]==0)
			{
				isWorking[i]=1;
				x[0]=x_start+stepSize*step;
				x[1]=x_start+stepSize*(step+1);
				MPI_Send(x,2,MPI_DOUBLE,i,0,MPI_COMM_WORLD);
				/* since we found an empty process, break*/
				stepIsSend=1;
				break;
			}	
		}
		if (!stepIsSend)
		{
			/* we need to wait for a proces to finish its work and receive it */
			MPI_Recv(y,2,MPI_DOUBLE,MPI_ANY_SOURCE,0,MPI_COMM_WORLD,&status);
			sum+=stepSize*0.5*(y[0]+y[1]);
			/* since that process is now ideling, give it some work */
			x[0]=x_start+stepSize*step;
			x[1]=x_start+stepSize*(step+1);
			MPI_Send(x,2,MPI_DOUBLE,status.MPI_SOURCE,0,MPI_COMM_WORLD);
		}

	}
	/* for each working process wait for its response */
	for (i=1;i<iNumProcs;i++)
	{
		if (isWorking[i])
		{
			MPI_Recv(y,2,MPI_DOUBLE,MPI_ANY_SOURCE,0,MPI_COMM_WORLD,&status);
			sum+=stepSize*0.5*(y[0]+y[1]);
			isWorking[i]=0;
		}
	}

	/* stop all workers*/
	for (nextRank=1;nextRank<iNumProcs;nextRank++)
		MPI_Send(&nextRank,0,MPI_INT,nextRank,2,MPI_COMM_WORLD);
	return sum;
#endif
}

void integral_slave()
{
	MPI_Status status;
	double xStart,xStride,y;
	int count,i;
	while(true)
	{
		/* get the status for the next incoming message */
		MPI_Probe(MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD, &status);
		/* if the  tag is 2, that the signal to stop */
		if (status.MPI_TAG==2) break;
	
		y=0.0;
		/* receive the left	 and right side of the trapezoid and compute the corresponding function values */
		MPI_Recv(&xStart,1,MPI_DOUBLE,0,MPI_ANY_TAG,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		MPI_Recv(&count,1,MPI_INT,0,MPI_ANY_TAG,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		MPI_Recv(&xStride,1,MPI_DOUBLE,0,MPI_ANY_TAG,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		for (i=0;i<count;i++)
			y+=function(xStart+xStride*i);
		/* send back the finished work */
//		printf("Partial sum is %f\n",y);
		MPI_Send(&y,1,MPI_DOUBLE,0,0,MPI_COMM_WORLD);	
	}

}


int main(int argc,char** argv)
{
	MPI_Init(&argc,&argv);
	double startTime,stopTime;
	int iMyRank;
	MPI_Comm_rank(MPI_COMM_WORLD,&iMyRank);
	if (iMyRank==0)
	{
		int iterationCount=100;
		if (argc > 1) {
			iterationCount=atoi(argv[1]);
		if (iterationCount<=0) exit(1);
		}
		startTime=MPI_Wtime();
		double pi=integral_master(function,0.0,1.0,iterationCount);
		stopTime=MPI_Wtime();
		printf("PI = %1.10g\t approximation = %1.10g\tDelta %1.10f\nComputation took %f seconds\n",M_PI,pi,fabs(M_PI-pi),stopTime-startTime);
	}
	else integral_slave();
	MPI_Finalize();

}
