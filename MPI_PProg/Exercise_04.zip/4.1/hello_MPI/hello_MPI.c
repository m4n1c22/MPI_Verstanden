#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
  int iMyRank, iNumProcs;
  
  int data;
  // TODO: initialize MPI, find out MPI size and rank
	

  

  // TODO: have only the first process execute the following code
  if (/* TODO */) 
    {
	  printf("Please provide an integer value for the ping-message conent:");
	  scanf("%d",&data); 	
      printf("Sending Ping ( %d)\n",data);
      // TODO: send data
      // TODO: receive data
	  printf("Received Pong (%d)\n",data);
    }
  // do proper receive and send for any other process
  else 
    {
	  printf("Received Ping (%d)\n",data);
      // TODO: receive data
	  	
      // TODO: calculate and send data
      printf("Sending Pong ( %d)\n",data);
    }

  // TODO: finish MPI


  return 0;
}
